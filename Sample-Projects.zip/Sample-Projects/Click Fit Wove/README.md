# Click Fit

Simple demo site with:
- Vanilla JS fetch to a public API
- Drag or click to upload images to the local server (saved in `upload_images`)
- MySQL script to create a `users` table and insert seed users

## Frontend
Open Click Fit Wove/Click fit.html in your browser.

## Backend (Node.js)
Requires Node 18+.

```cmd
npm install
node Click Fit Wove\server.js
```

Server runs on http://localhost:3000.

## Upload
- Use the upload box to add images
- Files are saved to `upload_images`

## MySQL
Run Click Fit Wove/mysql.sql in MySQL to create the table and insert users.
