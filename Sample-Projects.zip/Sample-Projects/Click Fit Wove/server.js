const path = require('path');
const fs = require('fs');
const express = require('express');
const multer = require('multer');

const app = express();
const PORT = process.env.PORT || 3000;

const uploadRoot = path.join(__dirname, 'upload_images');
if (!fs.existsSync(uploadRoot)) {
  fs.mkdirSync(uploadRoot, { recursive: true });
}

app.use(express.json());

const storage = multer.diskStorage({
  destination: function (req, file, cb) { cb(null, uploadRoot); },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname);
    const base = path.basename(file.originalname, ext);
    const safeBase = base.replace(/[^a-zA-Z0-9-_]/g, '_');
    cb(null, `${safeBase}-${Date.now()}${ext}`);
  }
});

const upload = multer({
  storage,
  fileFilter: function (req, file, cb) {
    const ok = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'].includes(file.mimetype);
    cb(null, ok);
  },
  limits: { fileSize: 10 * 1024 * 1024 }
});

app.get('/health', (req, res) => res.json({ ok: true }));

app.post('/upload', upload.array('images', 12), (req, res) => {
  const files = (req.files || []).map(f => ({ filename: path.basename(f.path), size: f.size }));
  res.json({ uploaded: files });
});

app.listen(PORT, () => {
  console.log(`Image upload server listening on http://localhost:${PORT}`);
});
